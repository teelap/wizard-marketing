EIGHT DOMINOES: A MESSAGING FRAMEWORK THAT COMPOUNDS INTO AWESOME CLIENTS — MEDIA KIT
=====================================================================================

By Jake "The Wizard" Tlapek. Foreword by Marty Marion.

WHAT'S IN HERE
  01-fact-sheet.txt        Title, format, ISBN, categories, endorsement.
  02-author-bios.txt       Three lengths. Take whichever fits the column.
  03-descriptions.txt      Book descriptions and boilerplate.
  04-story-angles.txt      Angles, interview questions, quotable lines.
  05-press-release.txt     The announcement, ready to run.
  06-usage-terms.txt       What you may do with these assets.
  images/                  Cover art (web + print) and audiobook cover.
  images/author-photography/
                           Nine author photos (October 2026).
                           Credit: "Photo: Nichole Gibbons."

Buy the book:      https://www.amazon.com/dp/B0HD48KJGD
Everything here is cleared for editorial use in coverage of the book,
the framework, or the author. Please don't crop or recolor the cover.

Latest version of this kit: /media-kit on the Eight Dominoes site.
